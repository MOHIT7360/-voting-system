<?php

$connect = mysqli_connect("localhost","root","","voting") or die("connection Failed !");
if(!$connect){
    echo"Not Connectd";
}
?>