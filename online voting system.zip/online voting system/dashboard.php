<?php
session_start();
if(!isset($_SESSION['userdata'])){
    header("loacation: ../");
}

$userdata = $_SESSION['userdata'];
$groupsdata = $_SESSION['groupsdata'];

if($_SESSION['userdata']['status']==0){
$status='<b style="color:red">Not voted </b>';
}
else{
    $status='<b style="color:green"> Voted </b>';
}
?>

<html >
    <center>
<Head>
<title> Onilne Voting System - Dashboard</title><br>
<link rel="stylesheet" href="stylesheet.css">
</Head>
<body>
<style>
    #backbtn{
    padding :10px;
    border-radius: 5px;
    background-color: blueviolet;
color: chartreuse;
float: left;
}
#logoutbtn{
    padding :10px;
    border-radius: 5px;
    background-color: blueviolet;
color: chartreuse;
float:right;
}

#profile{
background-color: white;
width : 40%;
padding:10px;
float: left;
}

#group{
    background-color: white;
width : 50%;
padding:10px;
float:right;
}
#votebtn{
    padding :10px;
    border-radius: 5px;
    background-color: blueviolet;
color: chartreuse;
float: left;
}
#voted{
    padding :10px;
    border-radius: 5px;
    background-color: blueviolet;
color: green;
float: left
}
</style>

<div id="main section">
<div id="headerscetion">
<a href="index.html"><button id="backbtn">Back</button></a>
<a href="index.html"> <button id="logoutbtn">Logout</button></a>
    <h1>Online Voting System </h1>
</div>
    <hr></center>
  
    <div id="profile">
<center><img src = "uploads/<?php echo $userdata['photo']?>"height="200" width="200"></center><br><br>
<b>NAME    :</b>   <?php echo $userdata['name']?><br><br>
<b>MOBILE  :</b> </b><?php echo $userdata['mobile']?> <br><br>
<b>ADDRESS :</b> </b><?php echo $userdata['address']?> <br><br>
<b>STATUS  :</b> </b><?php echo $status?> <br><br>
    </div>
  
    <div id="group">
<?php
// print_r($groupsdata);
if(isset($_SESSION['groupsdata'])){
    
for($i=0; $i<count($groupsdata); $i++){
    ?>
    <div >
    <img style="float:right" src="uploads/<?php echo $groupsdata[$i]['photo']; ?>" height="120" width="120"><br><br>
        <b>GROUP NAME:</b> <?php echo $groupsdata[$i]['name']?><br><br>
        <b>VOTES: </b><?php echo $groupsdata[$i]['votes']?><br<br>
        <form action="api/vote.php" method="POST">
            <input type="hidden" name="gvotes" value="<?php echo $groupsdata[$i]['votes']?>"><br>
            <input type="hidden" name="gid" value="<?php echo $groupsdata[$i]['id']?>">
            <?php 
            if($_SESSION['userdata']['status']==0){
                ?>
                <input type="submit" name="votesbtn" values="vote" id="votebtn"?>
           <?php
            }
            else
            {
                ?> 
              <button disabled> voted</button>
                <?php
            }
            ?>
           
        </form>
 </div>
<hr>
<?php
}
}
else{
    echo "hell";
}
?>
</div>
</div>
</form>